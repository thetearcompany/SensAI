export interface EmotionData {
  name: string;
  value: number;
}
